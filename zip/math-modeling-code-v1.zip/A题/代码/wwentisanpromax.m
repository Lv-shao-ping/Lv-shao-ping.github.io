%% 1. 参数初始化（基于投放策略核心参数）
clear; clc; close all;

% ---------------------- 目标与武器基础参数 ----------------------
% 真目标参数（圆柱形：下底面圆心(0,200,0)，半径7m，高10m）
T_center = [0, 200, 5];  % 真目标几何中心（z取高度中点）
T_radius = 7;            % 真目标水平半径
T_height = 10;           % 真目标高度

% 假目标参数（M1攻击靶点）
O = [0, 0, 0];           % 假目标坐标

% M1导弹参数
M1_init = [20000, 0, 2000];  % 初始位置(t=0)
M1_speed = 300;              % 飞行速度(m/s)
% M1方向向量（指向假目标O）
M1_dir = (O - M1_init) / norm(O - M1_init);  
t_M1 = 0:0.1:70;             % M1时间数组（0到70s，覆盖击中假目标全过程）
n_M1 = length(t_M1);         % M1轨迹点数

% ---------------------- 无人机FY1参数 ----------------------
FY1_init = [17800, 0, 1800];  % 初始位置(t=0)
FY1_speed = 140;              % 飞行速度（最大速度，m/s）
FY1_dir = [-0.997, 0.0714];   % 水平飞行方向单位向量(du,dv)
FY1_z = 1800;                 % 等高度飞行(z坐标)
% 3枚干扰弹投放时刻（间隔1s）
t_launch = [15, 16, 17];      % [弹1, 弹2, 弹3]投放时刻(s)
% 3枚干扰弹引信时间（控制起爆时刻）
t_fuse = [8, 9, 10];          % [弹1, 弹2, 弹3]引信时间(s)
g = 9.8;                      % 重力加速度(m/s²)

% ---------------------- 烟幕云团参数 ----------------------
smoke_radius = 10;            % 有效遮蔽半径(m)
smoke_sink_speed = 3;         % 匀速下沉速度(m/s)
smoke_valid_time = 20;        % 有效遮蔽时间(s)
% 3枚烟幕起爆时刻（投放时刻+引信时间）
t_detonate = t_launch + t_fuse;  


%% 2. 计算M1导弹飞行轨迹
M1_traj = zeros(n_M1, 3);  % 存储M1各时刻位置(x,y,z)
for i = 1:n_M1
    M1_traj(i, :) = M1_init + M1_speed * M1_dir * t_M1(i);
end


%% 3. 计算无人机FY1飞行轨迹及干扰弹投放点
% 无人机时间数组（0到20s，覆盖3枚弹投放后1s）
t_FY1 = 0:0.1:20;  
n_FY1 = length(t_FY1);
FY1_traj = zeros(n_FY1, 3);  % 无人机轨迹(x,y,z)
for i = 1:n_FY1
    t = t_FY1(i);
    FY1_traj(i, 1) = FY1_init(1) + FY1_speed * FY1_dir(1) * t;  % x方向
    FY1_traj(i, 2) = FY1_init(2) + FY1_speed * FY1_dir(2) * t;  % y方向
    FY1_traj(i, 3) = FY1_z;                                      % z方向（固定）
end

% 计算3枚干扰弹投放点P1/P2/P3（投放时刻的无人机位置）
P = zeros(3, 3);  % 3个投放点：P(1,:)=P1, P(2,:)=P2, P(3,:)=P3
for i = 1:3
    t = t_launch(i);
    P(i, 1) = FY1_init(1) + FY1_speed * FY1_dir(1) * t;
    P(i, 2) = FY1_init(2) + FY1_speed * FY1_dir(2) * t;
    P(i, 3) = FY1_z;
end


%% 4. 计算干扰弹起爆点及烟幕云团有效范围
% 4.1 计算起爆点Q1/Q2/Q3
Q = zeros(3, 3);  % 3个起爆点：Q(1,:)=Q1, Q(2,:)=Q2, Q(3,:)=Q3
for i = 1:3
    t_launch_i = t_launch(i);
    t_fuse_i = t_fuse(i);
    % 水平方向：干扰弹随无人机惯性运动（速度=无人机速度）
    Q(i, 1) = P(i, 1) + FY1_speed * FY1_dir(1) * t_fuse_i;
    Q(i, 2) = P(i, 2) + FY1_speed * FY1_dir(2) * t_fuse_i;
    % 垂直方向：受重力下落（z=投放点z - 0.5*g*t_fuse²）
    Q(i, 3) = P(i, 3) - 0.5 * g * t_fuse_i^2;
end

% 4.2 计算每枚烟幕云团的有效遮蔽轨迹（时间+空间）
% 弹1：有效时间t∈[t_detonate(1), t_detonate(1)+20]
t_smoke1 = t_detonate(1):0.1:(t_detonate(1)+smoke_valid_time);
smoke1_center = zeros(length(t_smoke1), 3);
for i = 1:length(t_smoke1)
    delta_t = t_smoke1(i) - t_detonate(1);
    smoke1_center(i, :) = [Q(1,1), Q(1,2), Q(1,3) - smoke_sink_speed * delta_t];
end

% 弹2：有效时间t∈[t_detonate(2), t_detonate(2)+20]
t_smoke2 = t_detonate(2):0.1:(t_detonate(2)+smoke_valid_time);
smoke2_center = zeros(length(t_smoke2), 3);
for i = 1:length(t_smoke2)
    delta_t = t_smoke2(i) - t_detonate(2);
    smoke2_center(i, :) = [Q(2,1), Q(2,2), Q(2,3) - smoke_sink_speed * delta_t];
end

% 弹3：有效时间t∈[t_detonate(3), t_detonate(3)+20]
t_smoke3 = t_detonate(3):0.1:(t_detonate(3)+smoke_valid_time);
smoke3_center = zeros(length(t_smoke3), 3);
for i = 1:length(t_smoke3)
    delta_t = t_smoke3(i) - t_detonate(3);
    smoke3_center(i, :) = [Q(3,1), Q(3,2), Q(3,3) - smoke_sink_speed * delta_t];
end


%% 5. 可视化展示（多子图布局）
figure('Position', [100, 100, 1200, 800]);

% 子图1：M1导弹轨迹与真目标（x-y平面投影）
subplot(2, 2, 1);
hold on; grid on; axis equal;
% 绘制M1轨迹
plot(M1_traj(:,1), M1_traj(:,2), 'r-', 'LineWidth', 1.5, 'DisplayName', 'M1导弹轨迹');
% 绘制真目标（圆形）- 使用patch函数创建圆形，更好地支持透明度
theta = linspace(0, 2*pi, 100);  % 生成角度
x_circle = T_center(1) + T_radius * cos(theta);  % 圆形x坐标
y_circle = T_center(2) + T_radius * sin(theta);  % 圆形y坐标
h = patch(x_circle, y_circle, 'g', 'FaceAlpha', 0.3, 'EdgeColor', 'none');
% 为圆形创建不可见线对象用于图例
plot(NaN, NaN, 'g', 'LineWidth', 1.5, 'Marker', 'o', 'MarkerFaceColor', 'g', 'DisplayName', '真目标');
% 标记假目标
scatter(O(1), O(2), 50, 'ko', 'filled', 'DisplayName', '假目标');
% 标记M1初始位置
scatter(M1_init(1), M1_init(2), 50, 'rs', 'filled', 'DisplayName', 'M1初始位置');
xlabel('x坐标 (m)'); ylabel('y坐标 (m)');
title('M1导弹轨迹与真/假目标位置（x-y平面）');
legend('Location', 'best');
xlim([-100, 21000]); ylim([-800, 400]);

% 子图2：无人机FY1轨迹与投放点（x-y平面投影）
subplot(2, 2, 2);
hold on; grid on; axis equal;
% 绘制无人机轨迹
plot(FY1_traj(:,1), FY1_traj(:,2), 'b-', 'LineWidth', 1.5, 'DisplayName', 'FY1飞行轨迹');
% 标记3个投放点 - 分别绘制每个点以确保颜色正确
scatter(P(1,1), P(1,2), 60, 'm', 'filled', 'DisplayName', 'P1(15s)');
scatter(P(2,1), P(2,2), 60, 'c', 'filled', 'DisplayName', 'P2(16s)');
scatter(P(3,1), P(3,2), 60, 'y', 'filled', 'DisplayName', 'P3(17s)');
% 标记无人机初始位置
scatter(FY1_init(1), FY1_init(2), 50, 'bs', 'filled', 'DisplayName', 'FY1初始位置');
xlabel('x坐标 (m)'); ylabel('y坐标 (m)');
title('无人机FY1轨迹与干扰弹投放点（x-y平面）');
legend('Location', 'best');
xlim([15000, 18000]); ylim([0, 200]);

% 子图3：烟幕云团有效遮蔽范围（x-z平面投影，t=35s）
subplot(2, 2, 3);
hold on; grid on;
% 绘制M1在t=35s的位置
t_marker = 35;
idx_m1 = find(t_M1 >= t_marker, 1);
scatter(M1_traj(idx_m1,1), M1_traj(idx_m1,3), 50, 'rs', 'filled', 'DisplayName', ['M1(t=', num2str(t_marker), 's)']);
% 为烟幕创建不可见线对象用于图例
plot(NaN, NaN, 'm', 'LineWidth', 1.5, 'Marker', 'o', 'MarkerFaceColor', 'm', 'DisplayName', '烟幕1(有效)');
plot(NaN, NaN, 'c', 'LineWidth', 1.5, 'Marker', 'o', 'MarkerFaceColor', 'c', 'DisplayName', '烟幕2(有效)');
plot(NaN, NaN, 'y', 'LineWidth', 1.5, 'Marker', 'o', 'MarkerFaceColor', 'y', 'DisplayName', '烟幕3(有效)');

% 绘制3枚烟幕在t=35s的有效范围 - 使用patch函数创建圆形
t_smoke_marker = 35;
theta = linspace(0, 2*pi, 100);  % 生成角度用于创建圆形
% 弹1
if t_smoke_marker >= t_detonate(1) && t_smoke_marker <= t_detonate(1)+20
    delta_t1 = t_smoke_marker - t_detonate(1);
    z1 = Q(1,3) - smoke_sink_speed * delta_t1;
    x_smoke1 = Q(1,1) + smoke_radius * cos(theta);
    z_smoke1 = z1 + smoke_radius * sin(theta);
    h1 = patch(x_smoke1, z_smoke1, 'm', 'FaceAlpha', 0.3, 'EdgeColor', 'none');
end
% 弹2
if t_smoke_marker >= t_detonate(2) && t_smoke_marker <= t_detonate(2)+20
    delta_t2 = t_smoke_marker - t_detonate(2);
    z2 = Q(2,3) - smoke_sink_speed * delta_t2;
    x_smoke2 = Q(2,1) + smoke_radius * cos(theta);
    z_smoke2 = z2 + smoke_radius * sin(theta);
    h2 = patch(x_smoke2, z_smoke2, 'c', 'FaceAlpha', 0.3, 'EdgeColor', 'none');
end
% 弹3
if t_smoke_marker >= t_detonate(3) && t_smoke_marker <= t_detonate(3)+20
    delta_t3 = t_smoke_marker - t_detonate(3);
    z3 = Q(3,3) - smoke_sink_speed * delta_t3;
    x_smoke3 = Q(3,1) + smoke_radius * cos(theta);
    z_smoke3 = z3 + smoke_radius * sin(theta);
    h3 = patch(x_smoke3, z_smoke3, 'y', 'FaceAlpha', 0.3, 'EdgeColor', 'none');
end
xlabel('x坐标 (m)'); ylabel('z坐标 (m)');
title(['t=', num2str(t_smoke_marker), 's 烟幕云团有效遮蔽范围（x-z平面）']);
legend('Location', 'best');
xlim([15300, 15800]); ylim([1200, 1500]);

% 子图4：遮蔽时长时间轴
subplot(2, 2, 4);
hold on; grid on;
% 绘制3枚烟幕的有效时间区间
smoke_color = ['m', 'c', 'y'];
for i = 1:3
    t_start = t_detonate(i);
    t_end = t_detonate(i) + smoke_valid_time;
    plot([t_start, t_end], [i, i], smoke_color(i), 'LineWidth', 8, 'DisplayName', ['烟幕', num2str(i)]);
    text(t_start, i+0.2, ['t=', num2str(t_start), 's'], 'HorizontalAlignment', 'center');
    text(t_end, i+0.2, ['t=', num2str(t_end), 's'], 'HorizontalAlignment', 'center');
end
% 标注M1击中假目标时间
plot([67, 67], [0, 4], 'k--', 'LineWidth', 1, 'DisplayName', 'M1击中假目标');
text(67, 3.5, 'M1击中假目标(t≈67s)', 'HorizontalAlignment', 'center');
xlabel('时间 (s)'); ylabel('烟幕编号');
title('3枚烟幕有效遮蔽时长时间轴');
ylim([0.5, 3.5]); xlim([0, 70]);
set(gca, 'YTick', [1,2,3], 'YTickLabel', ['烟幕1', '烟幕2', '烟幕3']);
legend('Location', 'best');


%% 6. 输出关键参数（验证策略约束）
fprintf('==================== 关键参数输出 ====================\n');
fprintf('1. 无人机FY1参数：\n');
fprintf('   飞行速度：%.1f m/s（范围：70~140 m/s，满足约束）\n', FY1_speed);
fprintf('   飞行方向：du=%.3f, dv=%.4f（单位向量，满足du²+dv²=%.3f）\n', FY1_dir(1), FY1_dir(2), sum(FY1_dir.^2));

fprintf('\n2. 3枚干扰弹投放与起爆参数：\n');
for i = 1:3
    fprintf('   烟幕%d：\n', i);
    fprintf('      投放时刻：%.1f s，投放点：(%.1f, %.1f, %.1f) m\n', ...
            t_launch(i), P(i,1), P(i,2), P(i,3));
    fprintf('      引信时间：%.1f s，起爆时刻：%.1f s\n', t_fuse(i), t_detonate(i));
    fprintf('      起爆点：(%.1f, %.1f, %.1f) m\n', Q(i,1), Q(i,2), Q(i,3));
    fprintf('      有效遮蔽时间：t in [%.1f, %.1f] s（共%.1f s）\n', ...
            t_detonate(i), t_detonate(i)+smoke_valid_time, smoke_valid_time);
end

fprintf('\n3. 约束验证：\n');
fprintf('   投放间隔：烟幕1-2=%.1f s，烟幕2-3=%.1f s（≥1 s，满足约束）\n', ...
        t_launch(2)-t_launch(1), t_launch(3)-t_launch(2));
fprintf('   总遮蔽时长：t in [%.1f, %.1f] s（共%.1f s，无连续间隙）\n', ...
        t_detonate(1), t_detonate(3)+smoke_valid_time, (t_detonate(3)+smoke_valid_time)-t_detonate(1));
