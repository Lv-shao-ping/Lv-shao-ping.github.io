% 优化问题2：最大化遮蔽时间
objective = @(x) -shielding_duration(x); % 负号用于最小化
lb = [70, 0, 0, 0]; % 下界: 无人机速度, 角度, 投放时间, 起爆延迟
ub = [140, 2*pi, 10, 10]; % 上界
options = optimoptions('ga', 'Display', 'iter', 'MaxGenerations', 50, 'OutputFcn', @gaoutfun);
[x_opt, fval, exitflag, output] = ga(objective, 4, [], [], [], [], lb, ub, [], options);
duration_opt = -fval;
disp(['最优参数: 无人机速度=', num2str(x_opt(1)), ' m/s, 角度=', num2str(rad2deg(x_opt(2))), ...
    '°, 投放时间=', num2str(x_opt(3)), ' s, 起爆延迟=', num2str(x_opt(4)), ' s']);
disp(['最大遮蔽时长: ', num2str(duration_opt), ' 秒']);

% 使用最优参数进行可视化
visualize_optimal_solution(x_opt);

% 遗传算法输出函数，用于记录迭代过程
function [state, options, optchanged] = gaoutfun(options, state, flag)
    persistent history
    optchanged = false;
    
    switch flag
        case 'init'
            history = [];
        case 'iter'
            bestfval = state.Best(end);
            history = [history; bestfval];
        case 'done'
            % 绘制收敛曲线
            figure('Position', [100, 100, 800, 400]);
            plot(1:length(history), -history, 'b-', 'LineWidth', 2);
            xlabel('迭代次数');
            ylabel('最佳适应度值 (遮蔽时长)');
            title('遗传算法收敛曲线');
            grid on;
            
            % 保存历史数据
            assignin('base', 'ga_history', history);
    end
end

% 可视化最优解
function visualize_optimal_solution(x_opt)
    g = 9.8;
    v_drone = x_opt(1);
    theta = x_opt(2);
    t_drop = x_opt(3);
    t_boom_delay = x_opt(4);
    drone_pos0 = [17800, 0, 1800];
    M1_pos0 = [20000, 0, 2000];
    target_pos = [0, 200, 0];
    
    % 无人机速度向量
    v_drone_vec = [v_drone*cos(theta), v_drone*sin(theta), 0];
    
    % 投放位置
    drop_pos = drone_pos0 + v_drone_vec * t_drop;
    
    % 爆炸时间
    t_boom = t_drop + t_boom_delay;
    
    % 爆炸位置
    x_boom = drop_pos(1) + v_drone_vec(1) * t_boom_delay;
    y_boom = drop_pos(2) + v_drone_vec(2) * t_boom_delay;
    z_boom = drop_pos(3) + v_drone_vec(3) * t_boom_delay - 0.5*g*t_boom_delay^2;
    
    % 导弹速度
    dir_vec = -M1_pos0;
    dist = norm(dir_vec);
    unit_vec = dir_vec / dist;
    v_missile = 300 * unit_vec;
    
    % 时间向量
    t_start = t_boom;
    t_end = t_boom + 20;
    t_vec = t_start:0.01:t_end;
    d_vec = zeros(size(t_vec));
    
    % 预计算导弹和云团位置
    missile_positions = zeros(length(t_vec), 3);
    cloud_positions = zeros(length(t_vec), 3);
    
    for i = 1:length(t_vec)
        t = t_vec(i);
        M1_pos = M1_pos0 + v_missile * t;
        missile_positions(i, :) = M1_pos;
        
        z_c = z_boom - 3*(t - t_boom);
        cloud_center = [x_boom, y_boom, z_c];
        cloud_positions(i, :) = cloud_center;
        
        A = M1_pos;
        B = target_pos;
        C = cloud_center;
        AB = B - A;
        AC = C - A;
        t_param = dot(AC, AB) / dot(AB, AB);
        if t_param < 0
            t_param = 0;
        elseif t_param > 1
            t_param = 1;
        end
        P = A + t_param * AB;
        d = norm(C - P);
        d_vec(i) = d;
    end
    
    % 计算有效遮蔽时长
    indices = find(d_vec <= 10);
    duration = length(indices) * 0.01;
    
    % 可视化
    figure('Position', [100, 100, 1200, 800]);
    
    % 1. 距离随时间变化
    subplot(2,2,1);
    plot(t_vec - t_boom, d_vec, 'b-', 'LineWidth', 1.5);
    hold on;
    area(t_vec(indices) - t_boom, d_vec(indices), 'FaceColor', 'g', 'FaceAlpha', 0.3);
    yline(10, 'r--', 'LineWidth', 2, 'Label', '有效遮蔽阈值');
    xlabel('爆炸后时间 (秒)');
    ylabel('距离 (米)');
    title('云团与导弹-目标连线之间的距离');
    legend('距离', '有效遮蔽时段', 'Location', 'best');
    grid on;
    
    % 2. 3D轨迹
    subplot(2,2,2);
    plot3(missile_positions(:,1), missile_positions(:,2), missile_positions(:,3), 'r-', 'LineWidth', 2);
    hold on;
    plot3(cloud_positions(:,1), cloud_positions(:,2), cloud_positions(:,3), 'b-', 'LineWidth', 2);
    plot3(target_pos(1), target_pos(2), target_pos(3), 'go', 'MarkerSize', 10, 'MarkerFaceColor', 'g');
    plot3(drone_pos0(1), drone_pos0(2), drone_pos0(3), 'ko', 'MarkerSize', 8, 'MarkerFaceColor', 'k');
    plot3(drop_pos(1), drop_pos(2), drop_pos(3), 'mo', 'MarkerSize', 8, 'MarkerFaceColor', 'm');
    plot3(x_boom, y_boom, z_boom, 'co', 'MarkerSize', 8, 'MarkerFaceColor', 'c');
    
    % 标记有效遮蔽位置
    effective_indices = find(d_vec <= 10);
    if ~isempty(effective_indices)
        plot3(cloud_positions(effective_indices,1), cloud_positions(effective_indices,2), ...
              cloud_positions(effective_indices,3), 'y.', 'MarkerSize', 10);
    end
    
    xlabel('X (米)');
    ylabel('Y (米)');
    zlabel('Z (米)');
    title('3D轨迹图');
    legend('导弹', '云团', '目标', '无人机起始点', '投放点', '爆炸点', '有效遮蔽点', 'Location', 'best');
    grid on;
    view(3);
    
    % 3. 高度随时间变化
    subplot(2,2,3);
    plot(t_vec - t_boom, missile_positions(:,3), 'r-', 'LineWidth', 2);
    hold on;
    plot(t_vec - t_boom, cloud_positions(:,3), 'b-', 'LineWidth', 2);
    xlabel('爆炸后时间 (秒)');
    ylabel('高度 (米)');
    title('高度随时间变化');
    legend('导弹', '云团', 'Location', 'best');
    grid on;
    
    % 4. 到目标的水平距离
    missile_dist_to_target = vecnorm(missile_positions(:,1:2) - target_pos(1:2), 2, 2);
    cloud_dist_to_target = vecnorm(cloud_positions(:,1:2) - target_pos(1:2), 2, 2);
    
    subplot(2,2,4);
    plot(t_vec - t_boom, missile_dist_to_target, 'r-', 'LineWidth', 2);
    hold on;
    plot(t_vec - t_boom, cloud_dist_to_target, 'b-', 'LineWidth', 2);
    xlabel('爆炸后时间 (秒)');
    ylabel('到目标的距离 (米)');
    title('到目标的水平距离');
    legend('导弹', '云团', 'Location', 'best');
    grid on;
    
    % 添加总标题
    sgtitle(sprintf('最优参数下的烟幕遮蔽效果 (遮蔽时长: %.2f 秒)', duration), 'FontSize', 16, 'FontWeight', 'bold');
    
    % 创建参数表
    param_names = {'无人机速度 (m/s)', '角度 (°)', '投放时间 (s)', '起爆延迟 (s)', '遮蔽时长 (s)'};
    param_values = [v_drone, rad2deg(theta), t_drop, t_boom_delay, duration];
    
    figure('Position', [100, 100, 600, 200]);
    uitable('Data', param_values, 'RowName', {}, 'ColumnName', param_names, ...
            'Position', [20, 20, 560, 160], 'ColumnWidth', {100});
    title('最优参数汇总');
end

% 计算遮蔽时长的函数
function duration = shielding_duration(x)
    g = 9.8;
    v_drone = x(1);
    theta = x(2);
    t_drop = x(3);
    t_boom_delay = x(4);
    drone_pos0 = [17800, 0, 1800];
    M1_pos0 = [20000, 0, 2000];
    target_pos = [0, 200, 0];
    
    % 无人机速度向量
    v_drone_vec = [v_drone*cos(theta), v_drone*sin(theta), 0];
    
    % 投放位置
    drop_pos = drone_pos0 + v_drone_vec * t_drop;
    
    % 爆炸时间
    t_boom = t_drop + t_boom_delay;
    
    % 爆炸位置
    x_boom = drop_pos(1) + v_drone_vec(1) * t_boom_delay;
    y_boom = drop_pos(2) + v_drone_vec(2) * t_boom_delay;
    z_boom = drop_pos(3) + v_drone_vec(3) * t_boom_delay - 0.5*g*t_boom_delay^2;
    
    % 导弹速度
    dir_vec = -M1_pos0;
    dist = norm(dir_vec);
    unit_vec = dir_vec / dist;
    v_missile = 300 * unit_vec;
    
    % 时间向量
    t_start = t_boom;
    t_end = t_boom + 20;
    t_vec = t_start:0.01:t_end;
    d_vec = zeros(size(t_vec));
    
    for i = 1:length(t_vec)
        t = t_vec(i);
        M1_pos = M1_pos0 + v_missile * t;
        z_c = z_boom - 3*(t - t_boom);
        cloud_center = [x_boom, y_boom, z_c];
        
        A = M1_pos;
        B = target_pos;
        C = cloud_center;
        AB = B - A;
        AC = C - A;
        t_param = dot(AC, AB) / dot(AB, AB);
        if t_param < 0
            t_param = 0;
        elseif t_param > 1
            t_param = 1;
        end
        P = A + t_param * AB;
        d = norm(C - P);
        d_vec(i) = d;
    end
    
    indices = find(d_vec <= 10);
    duration = length(indices) * 0.01;
end