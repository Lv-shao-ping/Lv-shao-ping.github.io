% 烟幕干扰弹投放策略优化 - 多模型对比完整脚本
clear; clc; close all;

% 设置中文显示
set(0, 'DefaultAxesFontName', 'SimHei');
set(0, 'DefaultTextFontName', 'SimHei');
set(0, 'DefaultFigureColor', 'w');

% 定义常量和初始条件
g = 9.8; % 重力加速度
v_smoke_sink = 3; % 烟幕下沉速度
smoke_effective_radius = 10; % 烟幕有效半径
smoke_effective_time = 20; % 烟幕有效时间
target_center = [0, 200, 5]; % 目标中心坐标
target_radius = 7; % 目标半径
target_height = 10; % 目标高度

% 导弹初始位置
missiles = [20000, 0, 2000; 
            19000, 600, 2100; 
            18000, -600, 1900];
missile_speed = 300; % 导弹速度
missile_names = {'M1', 'M2', 'M3'};

% 无人机初始位置
drones = [17800, 0, 1800;
          12000, 1400, 1400;
          6000, -3000, 700;
          11000, 2000, 1800;
          13000, -2000, 1300];
drone_names = {'FY1', 'FY2', 'FY3', 'FY4', 'FY5'};

% 算法参数
pop_size = 50; % 种群大小
max_gen = 100; % 最大代数

% 决策变量范围
min_speed = 70;
max_speed = 140;
min_heading = 0;
max_heading = 2*pi;
min_drop_time = 0;
max_drop_time = 70;
min_tau = 0;
max_tau = 20;

% 运行三种优化算法
fprintf('开始运行遗传算法(GA)...\n');
[ga_best_individual, ga_best_fitness, ga_history] = run_ga(drones, target_center, ...
    smoke_effective_radius, g, v_smoke_sink, smoke_effective_time, ...
    missiles, missile_speed, pop_size, max_gen);

fprintf('开始运行粒子群优化(PSO)...\n');
[pso_best_individual, pso_best_fitness, pso_history] = run_pso(drones, target_center, ...
    smoke_effective_radius, g, v_smoke_sink, smoke_effective_time, ...
    missiles, missile_speed, pop_size, max_gen);

fprintf('开始运行模拟退火(SA)...\n');
[sa_best_individual, sa_best_fitness, sa_history] = run_sa(drones, target_center, ...
    smoke_effective_radius, g, v_smoke_sink, smoke_effective_time, ...
    missiles, missile_speed, max_gen);

% 比较三种算法的结果
fprintf('\n算法比较结果:\n');
fprintf('遗传算法(GA)最佳适应度: %.2f\n', ga_best_fitness);
fprintf('粒子群优化(PSO)最佳适应度: %.2f\n', pso_best_fitness);
fprintf('模拟退火(SA)最佳适应度: %.2f\n', sa_best_fitness);

% 选择最佳个体
if ga_best_fitness >= pso_best_fitness && ga_best_fitness >= sa_best_fitness
    best_individual = ga_best_individual;
    best_algorithm = 'GA';
elseif pso_best_fitness >= ga_best_fitness && pso_best_fitness >= sa_best_fitness
    best_individual = pso_best_individual;
    best_algorithm = 'PSO';
else
    best_individual = sa_best_individual;
    best_algorithm = 'SA';
end

fprintf('选择 %s 算法的结果作为最终策略 (适应度: %.2f)\n', best_algorithm, max([ga_best_fitness, pso_best_fitness, sa_best_fitness]));

% 使用最佳个体生成最终策略
[drone_strategy, bomb_strategy, effective_times, missile_targets, total_effective_time, time_intervals] = generate_strategy(best_individual, drones, ...
                                                   target_center, g, v_smoke_sink, ...
                                                   smoke_effective_radius, smoke_effective_time, ...
                                                   missiles, missile_speed, missile_names);

% 保存结果到Excel
save_to_excel(drone_strategy, bomb_strategy, effective_times, missile_targets, drone_names, total_effective_time);

% 绘制收敛曲线比较
figure;
plot(1:length(ga_history), ga_history, 'b-', 'LineWidth', 1.5);
hold on;
plot(1:length(pso_history), pso_history, 'r-', 'LineWidth', 1.5);
plot(1:length(sa_history), sa_history, 'g-', 'LineWidth', 1.5);
xlabel('迭代次数');
ylabel('最佳适应度');
title('不同优化算法收敛曲线比较');
legend('遗传算法(GA)', '粒子群优化(PSO)', '模拟退火(SA)');
grid on;
hold off;

% 绘制无人机和导弹轨迹
plot_trajectories(drones, drone_strategy, missiles, missile_speed, target_center);

% 输出最终遮蔽时间
fprintf('\n最终遮蔽时间分析:\n');
fprintf('总有效遮蔽时间: %.2f秒\n', total_effective_time);
fprintf('各干扰弹有效遮蔽时间:\n');
for i = 1:length(effective_times)
    drone_idx = ceil(i/3);
    bomb_idx = mod(i-1, 3) + 1;
    fprintf('  %s的第%d枚干扰弹: %.2f秒\n', drone_names{drone_idx}, bomb_idx, effective_times(i));
end

% 绘制遮蔽时间区间图
plot_time_intervals(time_intervals, total_effective_time);

%% 遗传算法实现
function [best_individual, best_fitness, history] = run_ga(drones, target_center, ...
                                                         smoke_effective_radius, g, v_smoke_sink, ...
                                                         smoke_effective_time, missiles, missile_speed, ...
                                                         pop_size, max_gen)
    % 决策变量范围
    min_speed = 70;
    max_speed = 140;
    min_heading = 0;
    max_heading = 2*pi;
    min_drop_time = 0;
    max_drop_time = 70;
    min_tau = 0;
    max_tau = 20;
    
    mutation_rate = 0.1;
    
    % 初始化种群
    population = initialize_population(pop_size, drones, min_speed, max_speed, ...
                                      min_heading, max_heading, min_drop_time, ...
                                      max_drop_time, min_tau, max_tau);
    
    % 遗传算法主循环
    best_fitness = 0;
    best_individual = [];
    history = zeros(max_gen, 1);
    
    for gen = 1:max_gen
        % 评估适应度
        fitness = evaluate_population(population, drones, target_center, ...
                                     smoke_effective_radius, g, v_smoke_sink, ...
                                     smoke_effective_time, missiles, missile_speed);
        
        % 记录最佳个体
        [max_fit, idx] = max(fitness);
        history(gen) = max_fit;
        
        if max_fit > best_fitness
            best_fitness = max_fit;
            best_individual = population(idx,:);
        end
        
        % 选择
        selected = selection(population, fitness);
        
        % 交叉
        offspring = crossover(selected);
        
        % 变异
        offspring = mutation(offspring, mutation_rate, min_speed, max_speed, ...
                            min_heading, max_heading, min_drop_time, max_drop_time, ...
                            min_tau, max_tau);
        
        % 更新种群
        population = offspring;
        
        % 显示进度
        if mod(gen, 10) == 0
            fprintf('GA 第 %d 代, 最佳适应度: %.2f\n', gen, max_fit);
        end
    end
end

%% 粒子群优化实现
function [best_individual, best_fitness, history] = run_pso(drones, target_center, ...
                                                          smoke_effective_radius, g, v_smoke_sink, ...
                                                          smoke_effective_time, missiles, missile_speed, ...
                                                          pop_size, max_gen)
    % 决策变量范围
    min_speed = 70;
    max_speed = 140;
    min_heading = 0;
    max_heading = 2*pi;
    min_drop_time = 0;
    max_drop_time = 70;
    min_tau = 0;
    max_tau = 20;
    
    n_drones = size(drones, 1);
    n_vars = n_drones * 8; % 每个无人机有8个参数
    
    % PSO参数
    w = 0.7; % 惯性权重
    c1 = 1.5; % 个体学习因子
    c2 = 1.5; % 社会学习因子
    
    % 初始化粒子群
    particles = zeros(pop_size, n_vars);
    velocities = zeros(pop_size, n_vars);
    pbest = zeros(pop_size, n_vars);
    pbest_fitness = zeros(pop_size, 1);
    
    for i = 1:pop_size
        particles(i, :) = initialize_individual(drones, min_speed, max_speed, ...
                                               min_heading, max_heading, min_drop_time, ...
                                               max_drop_time, min_tau, max_tau);
        velocities(i, :) = zeros(1, n_vars);
        pbest(i, :) = particles(i, :);
        pbest_fitness(i) = evaluate_individual(particles(i, :), drones, target_center, ...
                                              smoke_effective_radius, g, v_smoke_sink, ...
                                              smoke_effective_time, missiles, missile_speed);
    end
    
    % 全局最佳
    [gbest_fitness, gbest_idx] = max(pbest_fitness);
    gbest = pbest(gbest_idx, :);
    
    % PSO主循环
    best_fitness = gbest_fitness;
    best_individual = gbest;
    history = zeros(max_gen, 1);
    
    for gen = 1:max_gen
        for i = 1:pop_size
            % 更新速度
            r1 = rand(1, n_vars);
            r2 = rand(1, n_vars);
            velocities(i, :) = w * velocities(i, :) + ...
                               c1 * r1 .* (pbest(i, :) - particles(i, :)) + ...
                               c2 * r2 .* (gbest - particles(i, :));
            
            % 更新位置
            particles(i, :) = particles(i, :) + velocities(i, :);
            
            % 边界处理
            particles(i, :) = bound_check(particles(i, :), drones, min_speed, max_speed, ...
                                         min_heading, max_heading, min_drop_time, max_drop_time, ...
                                         min_tau, max_tau);
            
            % 评估适应度
            fitness = evaluate_individual(particles(i, :), drones, target_center, ...
                                         smoke_effective_radius, g, v_smoke_sink, ...
                                         smoke_effective_time, missiles, missile_speed);
            
            % 更新个体最佳
            if fitness > pbest_fitness(i)
                pbest(i, :) = particles(i, :);
                pbest_fitness(i) = fitness;
                
                % 更新全局最佳
                if fitness > gbest_fitness
                    gbest = particles(i, :);
                    gbest_fitness = fitness;
                end
            end
        end
        
        history(gen) = gbest_fitness;
        
        if gbest_fitness > best_fitness
            best_fitness = gbest_fitness;
            best_individual = gbest;
        end
        
        % 显示进度
        if mod(gen, 10) == 0
            fprintf('PSO 第 %d 代, 最佳适应度: %.2f\n', gen, gbest_fitness);
        end
    end
end

%% 模拟退火实现
function [best_individual, best_fitness, history] = run_sa(drones, target_center, ...
                                                         smoke_effective_radius, g, v_smoke_sink, ...
                                                         smoke_effective_time, missiles, missile_speed, ...
                                                         max_gen)
    % 决策变量范围
    min_speed = 70;
    max_speed = 140;
    min_heading = 0;
    max_heading = 2*pi;
    min_drop_time = 0;
    max_drop_time = 70;
    min_tau = 0;
    max_tau = 20;
    
    n_drones = size(drones, 1);
    
    % SA参数
    T0 = 1000; % 初始温度
    Tf = 1;    % 最终温度
    alpha = 0.95; % 降温系数
    
    % 初始化当前解
    current_solution = initialize_individual(drones, min_speed, max_speed, ...
                                            min_heading, max_heading, min_drop_time, ...
                                            max_drop_time, min_tau, max_tau);
    current_fitness = evaluate_individual(current_solution, drones, target_center, ...
                                         smoke_effective_radius, g, v_smoke_sink, ...
                                         smoke_effective_time, missiles, missile_speed);
    
    % 最佳解
    best_solution = current_solution;
    best_fitness = current_fitness;
    
    % SA主循环
    T = T0;
    history = zeros(max_gen, 1);
    gen = 1;
    
    while T > Tf && gen <= max_gen
        % 生成新解
        new_solution = mutate_individual(current_solution, 1.0, min_speed, max_speed, ...
                                        min_heading, max_heading, min_drop_time, max_drop_time, ...
                                        min_tau, max_tau);
        new_fitness = evaluate_individual(new_solution, drones, target_center, ...
                                         smoke_effective_radius, g, v_smoke_sink, ...
                                         smoke_effective_time, missiles, missile_speed);
        
        % 计算适应度差
        delta = new_fitness - current_fitness;
        
        % 接受新解的条件
        if delta > 0 || rand() < exp(delta / T)
            current_solution = new_solution;
            current_fitness = new_fitness;
            
            if current_fitness > best_fitness
                best_solution = current_solution;
                best_fitness = current_fitness;
            end
        end
        
        % 降温
        T = T * alpha;
        history(gen) = best_fitness;
        gen = gen + 1;
        
        % 显示进度
        if mod(gen, 10) == 0
            fprintf('SA 第 %d 代, 最佳适应度: %.2f, 温度: %.2f\n', gen, best_fitness, T);
        end
    end
    
    best_individual = best_solution;
end

%% 辅助函数
function pop = initialize_population(pop_size, drones, min_speed, max_speed, ...
                                   min_heading, max_heading, min_drop_time, ...
                                   max_drop_time, min_tau, max_tau)
    n_drones = size(drones, 1);
    n_bombs_per_drone = 3;
    
    % 每个个体的编码: [速度1, 航向1, 投放时间1, τ1, 投放时间2, τ2, 投放时间3, τ3, ...]
    pop = zeros(pop_size, n_drones * (2 + n_bombs_per_drone * 2));
    
    for i = 1:pop_size
        individual = [];
        for d = 1:n_drones
            % 无人机速度和航向
            speed = min_speed + (max_speed - min_speed) * rand();
            heading = min_heading + (max_heading - min_heading) * rand();
            
            % 三枚干扰弹的投放时间和τ
            bomb_params = [];
            for b = 1:n_bombs_per_drone
                drop_time = min_drop_time + (max_drop_time - min_drop_time) * rand();
                tau = min_tau + (max_tau - min_tau) * rand();
                bomb_params = [bomb_params, drop_time, tau];
            end
            
            individual = [individual, speed, heading, bomb_params];
        end
        pop(i, :) = individual;
    end
end

function fitness = evaluate_population(population, drones, target_center, ...
                                     smoke_effective_radius, g, v_smoke_sink, ...
                                     smoke_effective_time, missiles, missile_speed)
    pop_size = size(population, 1);
    fitness = zeros(pop_size, 1);
    
    for i = 1:pop_size
        individual = population(i, :);
        total_effective_time = 0;
        
        % 计算每架无人机的贡献
        for d = 1:size(drones, 1)
            drone_pos = drones(d, :);
            idx = (d-1)*8 + 1;
            
            speed = individual(idx);
            heading = individual(idx+1);
            
            % 计算无人机运动方向向量
            dx = cos(heading);
            dy = sin(heading);
            
            % 计算三枚干扰弹的贡献
            for b = 1:3
                drop_time = individual(idx + 1 + 2*(b-1) + 1); % idx+2, idx+4, idx+6
                tau = individual(idx + 1 + 2*(b-1) + 2); % idx+3, idx+5, idx+7
                
                % 计算投放点
                drop_x = drone_pos(1) + speed * dx * drop_time;
                drop_y = drone_pos(2) + speed * dy * drop_time;
                drop_z = drone_pos(3);
                
                % 计算起爆点
                detonation_time = drop_time + tau;
                fall_distance = 0.5 * g * tau^2;
                detonation_z = drop_z - fall_distance;
                
                % 烟幕云团中心位置（考虑下沉）
                smoke_center = [drop_x + speed * dx * tau, ...
                               drop_y + speed * dy * tau, ...
                               detonation_z];
                
                % 计算有效遮蔽时间
                effective_time = calculate_effective_time(smoke_center, target_center, ...
                                                         detonation_time, v_smoke_sink, ...
                                                         smoke_effective_radius, smoke_effective_time);
                
                total_effective_time = total_effective_time + effective_time;
            end
        end
        
        fitness(i) = total_effective_time;
    end
end

function [effective_time, start_time, end_time] = calculate_effective_time(smoke_center, target_center, ...
                                                  detonation_time, v_smoke_sink, ...
                                                  smoke_effective_radius, smoke_effective_time)
    % 计算烟幕云团中心与目标中心的距离
    distance = norm(smoke_center - target_center);
    
    % 如果初始距离超过有效半径，计算何时进入有效范围
    if distance > smoke_effective_radius
        % 烟幕下沉过程中，中心与目标的距离会变化
        % 简化模型：假设烟幕中心垂直下沉
        vertical_distance = abs(smoke_center(3) - target_center(3));
        
        % 计算进入和离开有效范围的时间
        time_to_enter = max(0, (vertical_distance - smoke_effective_radius) / v_smoke_sink);
        time_in_effect = min(smoke_effective_time, 2 * smoke_effective_radius / v_smoke_sink);
        
        effective_time = max(0, time_in_effect - time_to_enter);
        start_time = detonation_time + time_to_enter;
        end_time = start_time + effective_time;
    else
        % 如果初始就在有效范围内
        vertical_distance = abs(smoke_center(3) - target_center(3));
        time_in_effect = min(smoke_effective_time, (smoke_effective_radius + vertical_distance) / v_smoke_sink);
        effective_time = time_in_effect;
        start_time = detonation_time;
        end_time = start_time + effective_time;
    end
end

function selected = selection(population, fitness)
    pop_size = size(population, 1);
    
    % 确保适应度为正值
    min_fit = min(fitness);
    if min_fit < 0
        fitness = fitness - min_fit + eps;
    end
    
    % 计算选择概率
    total_fitness = sum(fitness);
    prob = fitness / total_fitness;
    
    % 轮盘赌选择
    selected_idx = randsample(1:pop_size, pop_size, true, prob);
    selected = population(selected_idx, :);
end

function offspring = crossover(selected)
    pop_size = size(selected, 1);
    n_vars = size(selected, 2);
    offspring = zeros(size(selected));
    
    for i = 1:2:pop_size-1
        parent1 = selected(i, :);
        parent2 = selected(i+1, :);
        
        % 随机选择交叉点
        cross_point = randi([1, n_vars-1]);
        
        % 执行交叉
        offspring(i, :) = [parent1(1:cross_point), parent2(cross_point+1:end)];
        offspring(i+1, :) = [parent2(1:cross_point), parent1(cross_point+1:end)];
    end
end

function offspring = mutation(offspring, mutation_rate, min_speed, max_speed, ...
                             min_heading, max_heading, min_drop_time, max_drop_time, ...
                             min_tau, max_tau)
    pop_size = size(offspring, 1);
    n_vars = size(offspring, 2);
    n_drones = 5;
    
    for i = 1:pop_size
        if rand() < mutation_rate
            % 随机选择变异点
            mut_point = randi([1, n_vars]);
            
            % 根据变异点的位置确定变异范围
            drone_idx = ceil(mut_point / 8); % 确定属于哪个无人机
            param_idx = mod(mut_point - 1, 8) + 1; % 确定是哪个参数
            
            if param_idx == 1 % 速度参数
                offspring(i, mut_point) = min_speed + (max_speed - min_speed) * rand();
            elseif param_idx == 2 % 航向参数
                offspring(i, mut_point) = min_heading + (max_heading - min_heading) * rand();
            elseif ismember(param_idx, [3, 5, 7]) % 投放时间
                offspring(i, mut_point) = min_drop_time + (max_drop_time - min_drop_time) * rand();
            elseif ismember(param_idx, [4, 6, 8]) % τ参数
                offspring(i, mut_point) = min_tau + (max_tau - min_tau) * rand();
            end
        end
    end
end

function individual = initialize_individual(drones, min_speed, max_speed, ...
                                          min_heading, max_heading, min_drop_time, ...
                                          max_drop_time, min_tau, max_tau)
    n_drones = size(drones, 1);
    individual = [];
    
    for d = 1:n_drones
        % 无人机速度和航向
        speed = min_speed + (max_speed - min_speed) * rand();
        heading = min_heading + (max_heading - min_heading) * rand();
        
        % 三枚干扰弹的投放时间和τ
        bomb_params = [];
        for b = 1:3
            drop_time = min_drop_time + (max_drop_time - min_drop_time) * rand();
            tau = min_tau + (max_tau - min_tau) * rand();
            bomb_params = [bomb_params, drop_time, tau];
        end
        
        individual = [individual, speed, heading, bomb_params];
    end
end

function fitness = evaluate_individual(individual, drones, target_center, ...
                                     smoke_effective_radius, g, v_smoke_sink, ...
                                     smoke_effective_time, missiles, missile_speed)
    total_effective_time = 0;
    
    % 计算每架无人机的贡献
    for d = 1:size(drones, 1)
        drone_pos = drones(d, :);
        idx = (d-1)*8 + 1;
        
        speed = individual(idx);
        heading = individual(idx+1);
        
        % 计算无人机运动方向向量
        dx = cos(heading);
        dy = sin(heading);
        
        % 计算三枚干扰弹的贡献
        for b = 1:3
            drop_time = individual(idx + 1 + 2*(b-1) + 1); % idx+2, idx+4, idx+6
            tau = individual(idx + 1 + 2*(b-1) + 2); % idx+3, idx+5, idx+7
            
            % 计算投放点
            drop_x = drone_pos(1) + speed * dx * drop_time;
            drop_y = drone_pos(2) + speed * dy * drop_time;
            drop_z = drone_pos(3);
            
            % 计算起爆点
            detonation_time = drop_time + tau;
            fall_distance = 0.5 * g * tau^2;
            detonation_z = drop_z - fall_distance;
            
            % 烟幕云团中心位置（考虑下沉）
            smoke_center = [drop_x + speed * dx * tau, ...
                           drop_y + speed * dy * tau, ...
                           detonation_z];
            
            % 计算有效遮蔽时间
            effective_time = calculate_effective_time(smoke_center, target_center, ...
                                                     detonation_time, v_smoke_sink, ...
                                                     smoke_effective_radius, smoke_effective_time);
            
            total_effective_time = total_effective_time + effective_time;
        end
    end
    
    fitness = total_effective_time;
end

function individual = bound_check(individual, drones, min_speed, max_speed, ...
                                min_heading, max_heading, min_drop_time, max_drop_time, ...
                                min_tau, max_tau)
    n_drones = size(drones, 1);
    
    for d = 1:n_drones
        idx = (d-1)*8 + 1;
        
        % 速度和航向边界检查
        individual(idx) = max(min(individual(idx), max_speed), min_speed); % 速度
        individual(idx+1) = mod(individual(idx+1), 2*pi); % 航向，保持在0-2π范围内
        
        % 炸弹参数边界检查
        for b = 1:3
            drop_time_idx = idx + 1 + 2*(b-1) + 1;
            tau_idx = idx + 1 + 2*(b-1) + 2;
            
            individual(drop_time_idx) = max(min(individual(drop_time_idx), max_drop_time), min_drop_time);
            individual(tau_idx) = max(min(individual(tau_idx), max_tau), min_tau);
        end
    end
end

function mutated = mutate_individual(individual, mutation_rate, min_speed, max_speed, ...
                                   min_heading, max_heading, min_drop_time, max_drop_time, ...
                                   min_tau, max_tau)
    n_vars = length(individual);
    n_drones = 5;
    mutated = individual;
    
    for i = 1:n_vars
        if rand() < mutation_rate
            % 根据变异点的位置确定变异范围
            drone_idx = ceil(i / 8); % 确定属于哪个无人机
            param_idx = mod(i - 1, 8) + 1; % 确定是哪个参数
            
            if param_idx == 1 % 速度参数
                mutated(i) = min_speed + (max_speed - min_speed) * rand();
            elseif param_idx == 2 % 航向参数
                mutated(i) = min_heading + (max_heading - min_heading) * rand();
            elseif ismember(param_idx, [3, 5, 7]) % 投放时间
                mutated(i) = min_drop_time + (max_drop_time - min_drop_time) * rand();
            elseif ismember(param_idx, [4, 6, 8]) % τ参数
                mutated(i) = min_tau + (max_tau - min_tau) * rand();
            end
        end
    end
end

function [drone_strategy, bomb_strategy, effective_times, missile_targets, total_effective_time, time_intervals] = generate_strategy(best_individual, drones, ...
                                                           target_center, g, v_smoke_sink, ...
                                                           smoke_effective_radius, smoke_effective_time, ...
                                                           missiles, missile_speed, missile_names)
    n_drones = size(drones, 1);
    drone_strategy = cell(n_drones, 3); % 无人机编号, 速度, 航向角(度)
    bomb_strategy = cell(n_drones*3, 10); % 无人机编号, 弹序号, 投放时间, 投放点x,y,z, 起爆时间, 起爆点x,y,z
    effective_times = zeros(n_drones*3, 1);
    missile_targets = cell(n_drones*3, 1);
    time_intervals = cell(n_drones*3, 3); % 存储每个干扰弹的开始时间、结束时间和持续时间
    
    for d = 1:n_drones
        drone_pos = drones(d, :);
        idx = (d-1)*8 + 1;
        
        speed = best_individual(idx);
        heading = best_individual(idx+1);
        heading_deg = rad2deg(heading);
        if heading_deg < 0
            heading_deg = heading_deg + 360;
        end
        
        % 存储无人机策略
        drone_strategy{d, 1} = sprintf('FY%d', d);
        drone_strategy{d, 2} = heading_deg;
        drone_strategy{d, 3} = speed;
        
        % 计算无人机运动方向向量
        dx = cos(heading);
        dy = sin(heading);
        
        % 计算三枚干扰弹的参数
        for b = 1:3
            drop_time = best_individual(idx + 1 + 2*(b-1) + 1); % idx+2, idx+4, idx+6
            tau = best_individual(idx + 1 + 2*(b-1) + 2); % idx+3, idx+5, idx+7
            
            % 计算投放点
            drop_x = drone_pos(1) + speed * dx * drop_time;
            drop_y = drone_pos(2) + speed * dy * drop_time;
            drop_z = drone_pos(3);
            
            % 计算起爆点
            detonation_time = drop_time + tau;
            fall_distance = 0.5 * g * tau^2;
            detonation_z = drop_z - fall_distance;
            detonation_x = drop_x + speed * dx * tau;
            detonation_y = drop_y + speed * dy * tau;
            
            % 计算烟幕中心位置
            smoke_center = [detonation_x, detonation_y, detonation_z];
            
            % 计算有效遮蔽时间和时间区间
            [effective_time, start_time, end_time] = calculate_effective_time(smoke_center, target_center, ...
                                                     detonation_time, v_smoke_sink, ...
                                                     smoke_effective_radius, smoke_effective_time);
            
            % 确定干扰的导弹
            interfered_missiles = determine_interfered_missiles(smoke_center, detonation_time, ...
                                                               effective_time, missiles, missile_speed, ...
                                                               target_center, missile_names, smoke_effective_radius);
            
            % 存储炸弹策略
            row_idx = (d-1)*3 + b;
            bomb_strategy{row_idx, 1} = sprintf('FY%d', d);
            bomb_strategy{row_idx, 2} = b;
            bomb_strategy{row_idx, 3} = drop_time;
            bomb_strategy{row_idx, 4} = drop_x;
            bomb_strategy{row_idx, 5} = drop_y;
            bomb_strategy{row_idx, 6} = drop_z;
            bomb_strategy{row_idx, 7} = detonation_time;
            bomb_strategy{row_idx, 8} = detonation_x;
            bomb_strategy{row_idx, 9} = detonation_y;
            bomb_strategy{row_idx, 10} = detonation_z;
            
            effective_times(row_idx) = effective_time;
            missile_targets{row_idx} = interfered_missiles;
            
            % 存储时间区间信息
            time_intervals{row_idx, 1} = start_time;
            time_intervals{row_idx, 2} = end_time;
            time_intervals{row_idx, 3} = effective_time;
        end
    end
    
    % 计算总的有效遮蔽时间（考虑时间重叠）
    total_effective_time = calculate_total_effective_time(time_intervals);
end

function total_time = calculate_total_effective_time(time_intervals)
    % 将所有时间区间合并，计算总的有效遮蔽时间（考虑重叠）
    n_intervals = size(time_intervals, 1);
    intervals = zeros(n_intervals, 2);
    
    for i = 1:n_intervals
        intervals(i, 1) = time_intervals{i, 1};
        intervals(i, 2) = time_intervals{i, 2};
    end
    
    % 按开始时间排序
    [~, idx] = sort(intervals(:, 1));
    intervals = intervals(idx, :);
    
    % 合并重叠区间
    merged = [];
    current_start = intervals(1, 1);
    current_end = intervals(1, 2);
    
    for i = 2:n_intervals
        if intervals(i, 1) <= current_end
            % 区间重叠，扩展当前区间
            current_end = max(current_end, intervals(i, 2));
        else
            % 区间不重叠，保存当前区间并开始新区间
            merged = [merged; current_start, current_end];
            current_start = intervals(i, 1);
            current_end = intervals(i, 2);
        end
    end
    merged = [merged; current_start, current_end];
    
    % 计算总时间
    total_time = 0;
    for i = 1:size(merged, 1)
        total_time = total_time + (merged(i, 2) - merged(i, 1));
    end
end

function interfered_missiles = determine_interfered_missiles(smoke_center, detonation_time, ...
                                                           effective_time, missiles, missile_speed, ...
                                                           target_center, missile_names, smoke_effective_radius)
    n_missiles = size(missiles, 1);
    interfered_missiles = '';
    
    for m = 1:n_missiles
        missile_pos = missiles(m, :);
        missile_dir = (target_center - missile_pos) / norm(target_center - missile_pos);
        
        % 计算导弹到达目标的时间
        distance_to_target = norm(target_center - missile_pos);
        arrival_time = distance_to_target / missile_speed;
        
        % 计算导弹在烟幕起爆时的位置
        missile_pos_at_detonation = missile_pos + missile_dir * missile_speed * detonation_time;
        
        % 计算导弹与烟幕中心的距离
        distance_to_smoke = norm(missile_pos_at_detonation - smoke_center);
        
        % 如果距离小于烟幕有效半径，则认为干扰了该导弹
        if distance_to_smoke <= smoke_effective_radius
            if ~isempty(interfered_missiles)
                interfered_missiles = [interfered_missiles, ','];
            end
            interfered_missiles = [interfered_missiles, missile_names{m}];
        end
    end
    
    if isempty(interfered_missiles)
        interfered_missiles = '无';
    end
end

function save_to_excel(drone_strategy, bomb_strategy, effective_times, missile_targets, drone_names, total_effective_time)
    % 创建结果表格
    results = cell(19, 12); % 19行：15个炸弹 + 1个表头 + 3个备注行
    
    % 表头
    headers = {'无人机运动方向', '无人机运动速度 (m/s)', '烟幕干扰弹编号', ...
               '烟幕干扰弹投放点的x坐标 (m)', '烟幕干扰弹投放点的y坐标 (m)', '烟幕干扰弹投放点的z坐标 (m)', ...
               '烟幕干扰弹起爆点的x坐标 (m)', '烟幕干扰弹起爆点的y坐标 (m)', '烟幕干扰弹起爆点的z坐标 (m)', ...
               '有效干扰时长 (s)', '干扰的导弹编号'};
    
    for i = 1:length(headers)
        results{1, i} = headers{i};
    end
    
    % 填充数据
    row = 2;
    for d = 1:5
        drone_name = drone_names{d};
        drone_dir = drone_strategy{d, 2};
        drone_speed = drone_strategy{d, 3};
        
        for b = 1:3
            idx = (d-1)*3 + b;
            
            results{row, 1} = drone_dir;
            results{row, 2} = drone_speed;
            results{row, 3} = b;
            results{row, 4} = bomb_strategy{idx, 4};
            results{row, 5} = bomb_strategy{idx, 5};
            results{row, 6} = bomb_strategy{idx, 6};
            results{row, 7} = bomb_strategy{idx, 8};
            results{row, 8} = bomb_strategy{idx, 9};
            results{row, 9} = bomb_strategy{idx, 10};
            results{row, 10} = effective_times(idx);
            results{row, 11} = missile_targets{idx};
            
            row = row + 1;
        end
    end
    
    % 添加总遮蔽时间和备注
    results{17, 1} = '总有效遮蔽时间';
    results{17, 2} = total_effective_time;
    results{17, 3} = '秒';
    results{18, 1} = '注：以x轴为正向，逆时针方向为正，取值0~360（度）。';
    results{19, 1} = '注：总有效遮蔽时间已考虑时间重叠，是实际遮蔽时间。';
    
    % 尝试保存到不同位置或不同文件名
    filename = '烟幕干扰弹投放策略结果.xlsx';
    attempts = 0;
    max_attempts = 5;
    saved = false;
    
    while ~saved && attempts < max_attempts
        try
            % 检查文件是否存在，如果存在则尝试删除
            if exist(filename, 'file')
                delete(filename);
            end
            
            % 写入Excel文件
            writecell(results, filename, 'Sheet', 'Sheet1');
            saved = true;
            disp(['策略已保存到 ' filename]);
            
        catch ME
            attempts = attempts + 1;
            if attempts < max_attempts
                % 尝试使用不同的文件名
                filename = ['烟幕干扰弹投放策略结果_' datestr(now, 'yyyy-mm-dd_HH-MM-SS') '.xlsx'];
                disp(['尝试保存到 ' filename]);
                pause(1); % 等待一秒再试
            else
                % 如果所有尝试都失败，显示错误信息
                disp('无法保存Excel文件，可能的原因：');
                disp('1. 文件被其他程序打开');
                disp('2. 没有写入权限');
                disp('3. 磁盘空间不足');
                disp('错误信息：');
                disp(ME.message);
                
                % 将结果保存为CSV文件作为备用
                csv_filename = '烟幕干扰弹投放策略结果_backup.csv';
                writecell(results, csv_filename);
                disp(['已将结果备份保存到 ' csv_filename]);
            end
        end
    end
end

function plot_trajectories(drones, drone_strategy, missiles, missile_speed, target_center)
    figure;
    hold on;
    grid on;
    
    % 绘制目标
    plot3(target_center(1), target_center(2), target_center(3), 'ro', 'MarkerSize', 10, 'MarkerFaceColor', 'r');
    text(target_center(1), target_center(2), target_center(3), '目标', 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right');
    
    % 绘制导弹轨迹
    colors = ['r', 'g', 'b'];
    for m = 1:size(missiles, 1)
        missile_pos = missiles(m, :);
        missile_dir = (target_center - missile_pos) / norm(target_center - missile_pos);
        
        % 计算导弹到达目标的时间
        distance_to_target = norm(target_center - missile_pos);
        arrival_time = distance_to_target / missile_speed;
        
        % 生成轨迹点
        t = linspace(0, arrival_time, 100);
        trajectory = zeros(length(t), 3);
        for i = 1:length(t)
            trajectory(i, :) = missile_pos + missile_dir * missile_speed * t(i);
        end
        
        % 绘制轨迹
        plot3(trajectory(:, 1), trajectory(:, 2), trajectory(:, 3), [colors(m), '-'], 'LineWidth', 1.5);
        plot3(missile_pos(1), missile_pos(2), missile_pos(3), [colors(m), 'o'], 'MarkerSize', 8, 'MarkerFaceColor', colors(m));
        text(missile_pos(1), missile_pos(2), missile_pos(3), sprintf('M%d', m), 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right');
    end
    
    % 绘制无人机轨迹和干扰弹
    for d = 1:5
        drone_pos = drones(d, :);
        drone_dir_deg = drone_strategy{d, 2};
        drone_speed = drone_strategy{d, 3};
        drone_dir_rad = deg2rad(drone_dir_deg);
        
        dx = cos(drone_dir_rad);
        dy = sin(drone_dir_rad);
        
        % 绘制无人机初始位置
        plot3(drone_pos(1), drone_pos(2), drone_pos(3), 'ko', 'MarkerSize', 8, 'MarkerFaceColor', 'k');
        text(drone_pos(1), drone_pos(2), drone_pos(3), sprintf('FY%d', d), 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'right');
        
        % 绘制无人机轨迹
        max_time = 70;
        t = linspace(0, max_time, 100);
        trajectory = zeros(length(t), 3);
        for i = 1:length(t)
            trajectory(i, 1) = drone_pos(1) + drone_speed * dx * t(i);
            trajectory(i, 2) = drone_pos(2) + drone_speed * dy * t(i);
            trajectory(i, 3) = drone_pos(3);
        end
        plot3(trajectory(:, 1), trajectory(:, 2), trajectory(:, 3), 'k--', 'LineWidth', 1);
    end
    
    xlabel('X (m)');
    ylabel('Y (m)');
    zlabel('Z (m)');
    title('无人机和导弹轨迹');
    legend('目标', 'M1轨迹', 'M1', 'M2轨迹', 'M2', 'M3轨迹', 'M3', '无人机', 'Location', 'best');
    view(3);
    hold off;
end

function plot_time_intervals(time_intervals, total_effective_time)
    % 绘制时间区间图
    figure;
    hold on;
    
    n_intervals = size(time_intervals, 1);
    colors = lines(n_intervals);
    
    for i = 1:n_intervals
        start_time = time_intervals{i, 1};
        end_time = time_intervals{i, 2};
        duration = time_intervals{i, 3};
        
        % 绘制时间区间
        plot([start_time, end_time], [i, i], 'LineWidth', 10, 'Color', colors(i, :));
        text(start_time, i, sprintf('%.1fs', duration), 'VerticalAlignment', 'bottom', 'FontSize', 8);
    end
    
    yticks(1:n_intervals);
    yticklabels(arrayfun(@(x) sprintf('干扰弹%d', x), 1:n_intervals, 'UniformOutput', false));
    xlabel('时间 (秒)');
    ylabel('干扰弹');
    title(sprintf('各干扰弹有效遮蔽时间区间 (总时间: %.2f秒)', total_effective_time));
    grid on;
    hold off;
end