% Constants
g = 9.8;
v_drone = 120; % m/s
t_drop = 1.5; % s after mission start
t_boom_delay = 3.6; % s after drop
drone_pos0 = [17800, 0, 1800]; % initial drone position
M1_pos0 = [20000, 0, 2000]; % initial missile position
target_pos = [0, 200, 0]; % target position

% Calculate drop position
drop_pos = drone_pos0 + [-v_drone, 0, 0] * t_drop;

% Calculate boom time
t_boom = t_drop + t_boom_delay;

% Calculate boom position
x_boom = drop_pos(1) + (-v_drone) * t_boom_delay;
y_boom = drop_pos(2) + 0 * t_boom_delay;
z_boom = drop_pos(3) + 0 * t_boom_delay - 0.5 * g * t_boom_delay^2;

% Missile velocity calculation
dir_vec = -M1_pos0;
dist = norm(dir_vec);
unit_vec = dir_vec / dist;
v_missile = 300 * unit_vec;

% Time vector for cloud effectiveness
t_start = t_boom;
t_end = t_boom + 20;
t_vec = t_start:0.01:t_end;
d_vec = zeros(size(t_vec));

% Pre-calculate missile positions for visualization
missile_positions = zeros(length(t_vec), 3);
cloud_positions = zeros(length(t_vec), 3);

% Loop to compute distance for each time point
for i = 1:length(t_vec)
    t = t_vec(i);
    % Missile position at time t
    M1_pos = M1_pos0 + v_missile * t;
    missile_positions(i, :) = M1_pos;
    
    % Cloud center at time t
    z_c = z_boom - 3 * (t - t_boom);
    cloud_center = [x_boom, y_boom, z_c];
    cloud_positions(i, :) = cloud_center;
    
    % Calculate distance from cloud center to line segment between missile and target
    A = M1_pos;
    B = target_pos;
    C = cloud_center;
    AB = B - A;
    AC = C - A;
    t_param = dot(AC, AB) / dot(AB, AB);
    if t_param < 0
        t_param = 0;
    elseif t_param > 1
        t_param = 1;
    end
    P = A + t_param * AB;
    d = norm(C - P);
    d_vec(i) = d;
end

% Find duration where distance <= 10
indices = find(d_vec <= 10);
duration = length(indices) * 0.01;
disp(['有效遮蔽时长: ', num2str(duration), ' 秒']);

%% 可视化
% 设置中文字体
set(0, 'DefaultAxesFontName', 'SimHei');  % 设置默认字体为黑体
set(0, 'DefaultTextFontName', 'SimHei');   % 设置默认文本字体为黑体

% 1. 绘制云团与导弹-目标连线之间的距离随时间变化
figure('Position', [100, 100, 1200, 800]);
subplot(2,2,1);
plot(t_vec - t_boom, d_vec, 'b-', 'LineWidth', 1.5);
hold on;
area(t_vec(indices) - t_boom, d_vec(indices), 'FaceColor', 'g', 'FaceAlpha', 0.3);
yline(10, 'r--', 'LineWidth', 2, 'Label', '有效遮蔽阈值');
xlabel('爆炸后时间 (秒)');
ylabel('距离 (米)');
title('云团与导弹-目标连线之间的距离');
legend('距离', '有效遮蔽时段', 'Location', 'best');
grid on;

% 2. 绘制导弹和云团的3D轨迹
subplot(2,2,2);
plot3(missile_positions(:,1), missile_positions(:,2), missile_positions(:,3), 'r-', 'LineWidth', 2);
hold on;
plot3(cloud_positions(:,1), cloud_positions(:,2), cloud_positions(:,3), 'b-', 'LineWidth', 2);
plot3(target_pos(1), target_pos(2), target_pos(3), 'go', 'MarkerSize', 10, 'MarkerFaceColor', 'g');
plot3(drone_pos0(1), drone_pos0(2), drone_pos0(3), 'ko', 'MarkerSize', 8, 'MarkerFaceColor', 'k');
plot3(drop_pos(1), drop_pos(2), drop_pos(3), 'mo', 'MarkerSize', 8, 'MarkerFaceColor', 'm');
plot3(x_boom, y_boom, z_boom, 'co', 'MarkerSize', 8, 'MarkerFaceColor', 'c');

% 标记有效遮蔽位置
effective_indices = find(d_vec <= 10);
if ~isempty(effective_indices)
    plot3(cloud_positions(effective_indices,1), cloud_positions(effective_indices,2), ...
          cloud_positions(effective_indices,3), 'y.', 'MarkerSize', 10);
end

xlabel('X (米)');
ylabel('Y (米)');
zlabel('Z (米)');
title('3D轨迹图');
legend('导弹', '云团', '目标', '无人机起始点', '投放点', '爆炸点', '有效遮蔽点', 'Location', 'best');
grid on;
view(3);

% 3. 绘制高度随时间变化
subplot(2,2,3);
plot(t_vec - t_boom, missile_positions(:,3), 'r-', 'LineWidth', 2);
hold on;
plot(t_vec - t_boom, cloud_positions(:,3), 'b-', 'LineWidth', 2);
xlabel('爆炸后时间 (秒)');
ylabel('高度 (米)');
title('高度随时间变化');
legend('导弹', '云团', 'Location', 'best');
grid on;

% 4. 绘制到目标的水平距离随时间变化
missile_dist_to_target = vecnorm(missile_positions(:,1:2) - target_pos(1:2), 2, 2);
cloud_dist_to_target = vecnorm(cloud_positions(:,1:2) - target_pos(1:2), 2, 2);

subplot(2,2,4);
plot(t_vec - t_boom, missile_dist_to_target, 'r-', 'LineWidth', 2);
hold on;
plot(t_vec - t_boom, cloud_dist_to_target, 'b-', 'LineWidth', 2);
xlabel('爆炸后时间 (秒)');
ylabel('到目标的距离 (米)');
title('到目标的水平距离');
legend('导弹', '云团', 'Location', 'best');
grid on;

% 添加总标题
sgtitle('烟幕遮蔽效果分析', 'FontSize', 16, 'FontWeight', 'bold');

% 5. 创建场景动画
figure('Position', [100, 100, 800, 600]);
for i = 1:20:length(t_vec)  % 减少帧数以加快动画速度
    clf;
    
    % 绘制导弹轨迹到当前点
    plot3(missile_positions(1:i,1), missile_positions(1:i,2), missile_positions(1:i,3), 'r-', 'LineWidth', 2);
    hold on;
    
    % 绘制云团轨迹到当前点
    plot3(cloud_positions(1:i,1), cloud_positions(1:i,2), cloud_positions(1:i,3), 'b-', 'LineWidth', 2);
    
    % 绘制当前位置
    plot3(missile_positions(i,1), missile_positions(i,2), missile_positions(i,3), 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r');
    plot3(cloud_positions(i,1), cloud_positions(i,2), cloud_positions(i,3), 'bo', 'MarkerSize', 8, 'MarkerFaceColor', 'b');
    
    % 绘制目标和其他点
    plot3(target_pos(1), target_pos(2), target_pos(3), 'go', 'MarkerSize', 10, 'MarkerFaceColor', 'g');
    plot3(drone_pos0(1), drone_pos0(2), drone_pos0(3), 'ko', 'MarkerSize', 8, 'MarkerFaceColor', 'k');
    plot3(drop_pos(1), drop_pos(2), drop_pos(3), 'mo', 'MarkerSize', 8, 'MarkerFaceColor', 'm');
    plot3(x_boom, y_boom, z_boom, 'co', 'MarkerSize', 8, 'MarkerFaceColor', 'c');
    
    % 绘制导弹和目标之间的连线
    plot3([missile_positions(i,1), target_pos(1)], ...
          [missile_positions(i,2), target_pos(2)], ...
          [missile_positions(i,3), target_pos(3)], 'k--');
    
    % 如果适用，绘制有效遮蔽球体
    if d_vec(i) <= 10
        [X, Y, Z] = sphere(20);
        X = X * 10 + cloud_positions(i,1);
        Y = Y * 10 + cloud_positions(i,2);
        Z = Z * 10 + cloud_positions(i,3);
        surf(X, Y, Z, 'FaceAlpha', 0.2, 'EdgeColor', 'none', 'FaceColor', 'g');
    end
    
    xlabel('X (米)');
    ylabel('Y (米)');
    zlabel('Z (米)');
    title(sprintf('时间: %.2f 秒 (爆炸后)', t_vec(i) - t_boom));
    legend('导弹路径', '云团路径', '导弹', '云团', '目标', '无人机起始点', '投放点', '爆炸点', 'Location', 'best');
    grid on;
    view(3);
    axis equal;
    
    % 设置一致的坐标轴范围
    xlim([min([missile_positions(:,1); cloud_positions(:,1); target_pos(1)])-1000, ...
          max([missile_positions(:,1); cloud_positions(:,1); target_pos(1)])+1000]);
    ylim([min([missile_positions(:,2); cloud_positions(:,2); target_pos(2)])-1000, ...
          max([missile_positions(:,2); cloud_positions(:,2); target_pos(2)])+1000]);
    zlim([0, max([missile_positions(:,3); cloud_positions(:,3); target_pos(3)])+1000]);
    
    drawnow;
end

% 6. 创建遮蔽效果总结图
figure('Position', [200, 200, 800, 400]);

% 绘制遮蔽状态随时间变化
subplot(1,2,1);
shielded = d_vec <= 10;
stairs(t_vec - t_boom, shielded, 'b-', 'LineWidth', 2);
xlabel('爆炸后时间 (秒)');
ylabel('遮蔽状态');
title('遮蔽状态随时间变化');
ylim([-0.1, 1.1]);
yticks([0, 1]);
yticklabels({'未遮蔽', '遮蔽'});
grid on;

% 绘制累积遮蔽时间
subplot(1,2,2);
cumulative_shielded = cumsum(shielded) * 0.01;
plot(t_vec - t_boom, cumulative_shielded, 'r-', 'LineWidth', 2);
xlabel('爆炸后时间 (秒)');
ylabel('累积遮蔽时间 (秒)');
title('累积遮蔽时间');
grid on;

% 添加总标题
sgtitle(sprintf('烟幕遮蔽效果总结 (总遮蔽时长: %.2f 秒)', duration), 'FontSize', 14, 'FontWeight', 'bold');