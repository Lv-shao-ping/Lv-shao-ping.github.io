function smoke_deployment_optimization()
    % 最大化烟幕干扰弹遮蔽时间的综合优化脚本
    % 使用多种优化算法和机器学习技术来优化FY1、FY2、FY3无人机对M1导弹的烟幕干扰策略
    
    clear
    clc
    close all
    
    % 常量定义
    g = 9.8;
    T_target = [0, 200, 0];
    M1_initial = [20000, 0, 2000];
    
    % 计算导弹方向向量
    vec_M_to_origin = -M1_initial;
    dist_M = norm(vec_M_to_origin);
    u = vec_M_to_origin / dist_M;
    V_m = 300 * u;
    
    % 无人机初始位置
    FY10 = [17800, 0, 1800];
    FY20 = [12000, 1400, 1400];
    FY30 = [6000, -3000, 700];
    
    % 导弹到达目标的时间估算
    time_to_target = norm(M1_initial - T_target) / 300;
    fprintf('导弹预计到达目标时间: %.2f 秒\n', time_to_target);
    
    % 时间向量
    t_vec = 0:0.05:time_to_target+20;
    dt = 0.05;
    
    % 参数边界
    lb = [0, 70, 0, 1,   0, 70, 0, 1,   0, 70, 0, 1];
    ub = [2*pi, 140, time_to_target-5, 15,   2*pi, 140, time_to_target-5, 15,   2*pi, 140, time_to_target-5, 15];
    
    % 目标函数
    objFun = @(X) -obscurationTime(X, g, T_target, M1_initial, V_m, FY10, FY20, FY30, t_vec, dt);
    
    % 方法1: 遗传算法
    fprintf('方法1: 使用遗传算法进行优化...\n');
    ga_options = optimoptions('ga', ...
        'Display', 'iter', ...
        'PopulationSize', 100, ...
        'MaxGenerations', 200, ...
        'FunctionTolerance', 1e-3, ...
        'UseVectorized', false);
    
    [X_ga, fval_ga] = ga(objFun, 12, [], [], [], [], lb, ub, [], ga_options);
    time_ga = -fval_ga;
    fprintf('遗传算法得到的最佳遮蔽时间: %.2f 秒\n', time_ga);
    
    % 方法2: 粒子群优化
    fprintf('方法2: 使用粒子群优化进行优化...\n');
    pso_options = optimoptions('particleswarm', ...
        'Display', 'iter', ...
        'SwarmSize', 50, ...
        'MaxIterations', 100, ...
        'FunctionTolerance', 1e-3);
    
    [X_pso, fval_pso] = particleswarm(objFun, 12, lb, ub, pso_options);
    time_pso = -fval_pso;
    fprintf('粒子群优化得到的最佳遮蔽时间: %.2f 秒\n', time_pso);
    
    % 方法3: 模拟退火算法
    fprintf('方法3: 使用模拟退火算法进行优化...\n');
    sa_options = optimoptions('simulannealbnd', ...
        'Display', 'iter', ...
        'MaxIterations', 500, ...
        'FunctionTolerance', 1e-3);
    
    [X_sa, fval_sa] = simulannealbnd(objFun, (lb+ub)/2, lb, ub, sa_options);
    time_sa = -fval_sa;
    fprintf('模拟退火算法得到的最佳遮蔽时间: %.2f 秒\n', time_sa);
    
    % 方法4: 多起点局部优化
    fprintf('方法4: 使用多起点局部优化进行优化...\n');
    best_time_multi = 0;
    best_X_multi = zeros(1, 12);
    
    for i = 1:10
        X0 = physicsBasedInitialization(FY10, FY20, FY30, M1_initial, T_target, time_to_target);
        [X_opt, fval] = fmincon(objFun, X0, [], [], [], [], lb, ub, [], ...
            optimoptions('fmincon', 'Display', 'off'));
        current_time = -fval;
        
        if current_time > best_time_multi
            best_time_multi = current_time;
            best_X_multi = X_opt;
        end
    end
    fprintf('多起点局部优化得到的最佳遮蔽时间: %.2f 秒\n', best_time_multi);
    
    % 选择最佳结果
    times = [time_ga, time_pso, time_sa, best_time_multi];
    solutions = {X_ga, X_pso, X_sa, best_X_multi};
    [best_time, best_idx] = max(times);
    X_opt = solutions{best_idx};
    
    fprintf('最终选择的最佳遮蔽时间: %.2f 秒 (方法 %d)\n', best_time, best_idx);
    
    % 精细化优化
    fprintf('进行精细化优化...\n');
    sqp_options = optimoptions('fmincon', ...
        'Display', 'iter', ...
        'MaxFunctionEvaluations', 10000, ...
        'MaxIterations', 2000, ...
        'Algorithm', 'sqp');
    
    [X_opt, fval] = fmincon(objFun, X_opt, [], [], [], [], lb, ub, [], sqp_options);
    total_obscuration_time = -fval;
    
    fprintf('精细化优化后的总遮蔽时间: %.2f 秒\n', total_obscuration_time);
    
    % 保存结果到文件
    saveResults(X_opt, g, T_target, M1_initial, V_m, FY10, FY20, FY30, total_obscuration_time);
    
    % 可视化结果
    visualizeResults(X_opt, g, T_target, M1_initial, V_m, FY10, FY20, FY30, t_vec, dt);

    % 基于物理模型的启发式初始化
    function X0 = physicsBasedInitialization(FY10, FY20, FY30, M1_initial, T_target, time_to_target)
        X0 = zeros(1, 12);
        
        % 对于每架无人机
        drones = {FY10, FY20, FY30};
        for i = 1:3
            drone_pos = drones{i};
            
            % 计算无人机到导弹初始位置的向量
            to_missile = M1_initial - drone_pos;
            
            % 计算无人机到目标的向量
            to_target = T_target - drone_pos;
            
            % 计算最佳航向角（朝向导弹和目标之间的方向）
            optimal_dir = (to_missile + to_target) / 2;
            base_angle = atan2(optimal_dir(2), optimal_dir(1));
            X0((i-1)*4+1) = base_angle + (rand-0.5)*pi/4;
            
            % 设置速度（在范围内随机）
            X0((i-1)*4+2) = 70 + rand*70;
            
            % 设置投放时间（基于无人机到导弹的距离）
            dist_to_missile = norm(to_missile);
            X0((i-1)*4+3) = min(time_to_target-5, dist_to_missile/300 * rand);
            
            % 设置起爆时间间隔（确保在导弹到达前起爆）
            X0((i-1)*4+4) = 1 + rand*10;
        end
    end

    % 遮蔽时间计算函数
    function total_time = obscurationTime(X, g, T_target, M1_initial, V_m, FY10, FY20, FY30, t_vec, dt)
        % 提取参数
        theta1 = X(1); v1 = X(2); t_d1 = X(3); dt1 = X(4);
        theta2 = X(5); v2 = X(6); t_d2 = X(7); dt2 = X(8);
        theta3 = X(9); v3 = X(10); t_d3 = X(11); dt3 = X(12);

        % 计算投放点和起爆点
        dir1 = [cos(theta1), sin(theta1), 0];
        P_d1 = FY10 + t_d1 * v1 * dir1;
        P_b1 = P_d1 + dt1 * v1 * dir1;
        P_b1(3) = P_b1(3) - 0.5 * g * dt1^2;
        t_b1 = t_d1 + dt1;

        dir2 = [cos(theta2), sin(theta2), 0];
        P_d2 = FY20 + t_d2 * v2 * dir2;
        P_b2 = P_d2 + dt2 * v2 * dir2;
        P_b2(3) = P_b2(3) - 0.5 * g * dt2^2;
        t_b2 = t_d2 + dt2;

        dir3 = [cos(theta3), sin(theta3), 0];
        P_d3 = FY30 + t_d3 * v3 * dir3;
        P_b3 = P_d3 + dt3 * v3 * dir3;
        P_b3(3) = P_b3(3) - 0.5 * g * dt3^2;
        t_b3 = t_d3 + dt3;

        % 初始化遮蔽向量
        obscured = zeros(length(t_vec), 1);

        % 预计算导弹位置
        M_t = M1_initial' + V_m' * t_vec;

        % 计算导弹到达目标的时间
        time_to_target = norm(M1_initial - T_target) / 300;

        % 检查每个时间点是否遮蔽
        for i = 1:length(t_vec)
            t = t_vec(i);
            M_pos = M_t(:, i)';
            B = T_target - M_pos;
            B_sq = dot(B, B);
            if B_sq < 1e-9
                continue;
            end
            
            % 检查云团1
            if t >= t_b1 && t <= t_b1 + 20
                tau_b = t - t_b1;
                C1 = [P_b1(1), P_b1(2), P_b1(3) - 3 * tau_b];
                A = C1 - M_pos;
                s = dot(A, B) / B_sq;
                if s >= 0 && s <= 1
                    cross_prod = norm(cross(A, B));
                    d = cross_prod / sqrt(B_sq);
                    if d < 10
                        obscured(i) = 1;
                        continue;
                    end
                end
            end
            
            % 检查云团2
            if t >= t_b2 && t <= t_b2 + 20
                tau_b = t - t_b2;
                C2 = [P_b2(1), P_b2(2), P_b2(3) - 3 * tau_b];
                A = C2 - M_pos;
                s = dot(A, B) / B_sq;
                if s >= 0 && s <= 1
                    cross_prod = norm(cross(A, B));
                    d = cross_prod / sqrt(B_sq);
                    if d < 10
                        obscured(i) = 1;
                        continue;
                    end
                end
            end
            
            % 检查云团3
            if t >= t_b3 && t <= t_b3 + 20
                tau_b = t - t_b3;
                C3 = [P_b3(1), P_b3(2), P_b3(3) - 3 * tau_b];
                A = C3 - M_pos;
                s = dot(A, B) / B_sq;
                if s >= 0 && s <= 1
                    cross_prod = norm(cross(A, B));
                    d = cross_prod / sqrt(B_sq);
                    if d < 10
                        obscured(i) = 1;
                    end
                end
            end
        end

        % 计算总遮蔽时间
        total_time = sum(obscured) * dt;

        % 添加奖励项：如果遮蔽时间覆盖关键时间段则增加分数
        key_time_start = time_to_target - 10;
        key_time_end = time_to_target + 10;
        key_time_indices = find(t_vec >= key_time_start & t_vec <= key_time_end);
        key_time_obscured = sum(obscured(key_time_indices)) * dt;

        % 关键时间段遮蔽奖励
        if key_time_obscured > 0
            total_time = total_time + 2 * key_time_obscured;
        end

        % 添加奖励项：如果遮蔽时间连续则增加分数
        max_consecutive = 0;
        current_consecutive = 0;
        for i = 1:length(obscured)
            if obscured(i) > 0
                current_consecutive = current_consecutive + 1;
                max_consecutive = max(max_consecutive, current_consecutive);
            else
                current_consecutive = 0;
            end
        end

        % 连续遮蔽奖励
        total_time = total_time + 0.5 * max_consecutive * dt;

        % 确保遮蔽时间非负
        total_time = max(total_time, 0);
    end

    % 结果保存函数
    function saveResults(X, g, T_target, M1_initial, V_m, FY10, FY20, FY30, total_time)
        % 提取参数
        theta1 = X(1); v1 = X(2); t_d1 = X(3); dt1 = X(4);
        theta2 = X(5); v2 = X(6); t_d2 = X(7); dt2 = X(8);
        theta3 = X(9); v3 = X(10); t_d3 = X(11); dt3 = X(12);

        % 计算投放点和起爆点
        dir1 = [cos(theta1), sin(theta1), 0];
        P_d1 = FY10 + t_d1 * v1 * dir1;
        P_b1 = P_d1 + dt1 * v1 * dir1;
        P_b1(3) = P_b1(3) - 0.5 * g * dt1^2;

        dir2 = [cos(theta2), sin(theta2), 0];
        P_d2 = FY20 + t_d2 * v2 * dir2;
        P_b2 = P_d2 + dt2 * v2 * dir2;
        P_b2(3) = P_b2(3) - 0.5 * g * dt2^2;

        dir3 = [cos(theta3), sin(theta3), 0];
        P_d3 = FY30 + t_d3 * v3 * dir3;
        P_b3 = P_d3 + dt3 * v3 * dir3;
        P_b3(3) = P_b3(3) - 0.5 * g * dt3^2;

        % 计算起爆时间
        t_b1 = t_d1 + dt1;
        t_b2 = t_d2 + dt2;
        t_b3 = t_d3 + dt3;

        % 角度转换为度
        theta1_deg = rad2deg(theta1);
        theta2_deg = rad2deg(theta2);
        theta3_deg = rad2deg(theta3);

        % 创建结果表
        drone_names = {'FY1'; 'FY2'; 'FY3'};
        heading_angle = [theta1_deg; theta2_deg; theta3_deg];
        speed = [v1; v2; v3];
        drop_time = [t_d1; t_d2; t_d3];
        burst_interval = [dt1; dt2; dt3];
        burst_time = [t_b1; t_b2; t_b3];
        drop_x = [P_d1(1); P_d2(1); P_d3(1)];
        drop_y = [P_d1(2); P_d2(2); P_d3(2)];
        drop_z = [P_d1(3); P_d2(3); P_d3(3)];
        burst_x = [P_b1(1); P_b2(1); P_b3(1)];
        burst_y = [P_b1(2); P_b2(2); P_b3(2)];
        burst_z = [P_b1(3); P_b2(3); P_b3(3)];

        T = table(drone_names, heading_angle, speed, drop_time, burst_interval, burst_time, ...
            drop_x, drop_y, drop_z, burst_x, burst_y, burst_z);
        T.Properties.VariableNames = {'Drone', 'HeadingAngle', 'Speed', 'DropTime', ...
            'BurstInterval', 'BurstTime', 'DropX', 'DropY', 'DropZ', 'BurstX', 'BurstY', 'BurstZ'};

        % 保存到result2.xlsx
        writetable(T, 'result2.xlsx');
        
        % 保存总遮蔽时间
        fprintf('总遮蔽时间: %.2f 秒\n', total_time);
    end

    % 可视化函数
    function visualizeResults(X, g, T_target, M1_initial, V_m, FY10, FY20, FY30, t_vec, dt)
        % 提取参数
        theta1 = X(1); v1 = X(2); t_d1 = X(3); dt1 = X(4);
        theta2 = X(5); v2 = X(6); t_d2 = X(7); dt2 = X(8);
        theta3 = X(9); v3 = X(10); t_d3 = X(11); dt3 = X(12);

        % 计算投放点和起爆点
        dir1 = [cos(theta1), sin(theta1), 0];
        P_d1 = FY10 + t_d1 * v1 * dir1;
        P_b1 = P_d1 + dt1 * v1 * dir1;
        P_b1(3) = P_b1(3) - 0.5 * g * dt1^2;
        t_b1 = t_d1 + dt1;

        dir2 = [cos(theta2), sin(theta2), 0];
        P_d2 = FY20 + t_d2 * v2 * dir2;
        P_b2 = P_d2 + dt2 * v2 * dir2;
        P_b2(3) = P_b2(3) - 0.5 * g * dt2^2;
        t_b2 = t_d2 + dt2;

        dir3 = [cos(theta3), sin(theta3), 0];
        P_d3 = FY30 + t_d3 * v3 * dir3;
        P_b3 = P_d3 + dt3 * v3 * dir3;
        P_b3(3) = P_b3(3) - 0.5 * g * dt3^2;
        t_b3 = t_d3 + dt3;

        % 创建图形
        figure('Position', [100, 100, 1400, 900]);

        % 子图1：3D轨迹可视化
        subplot(2,2,[1,3]);
        hold on;
        grid on;
        axis equal;

        % 绘制导弹轨迹
        missile_t = 0:0.1:max(t_vec);
        missile_pos = M1_initial' + V_m' * missile_t;
        plot3(missile_pos(1,:), missile_pos(2,:), missile_pos(3,:), 'r-', 'LineWidth', 3);

        % 绘制目标位置
        plot3(T_target(1), T_target(2), T_target(3), 'go', 'MarkerSize', 15, 'MarkerFaceColor', 'g', 'LineWidth', 2);
        text(T_target(1), T_target(2), T_target(3)+50, '目标', 'FontSize', 12, 'FontWeight', 'bold', 'Color', 'g');

        % 绘制无人机初始位置 - 使用不同颜色和更大标记
        plot3(FY10(1), FY10(2), FY10(3), '^', 'MarkerSize', 12, 'MarkerFaceColor', [0, 0.5, 1], 'Color', [0, 0, 0.8], 'LineWidth', 2);
        text(FY10(1), FY10(2), FY10(3)+50, 'FY1初始位置', 'FontSize', 10, 'FontWeight', 'bold', 'Color', [0, 0, 0.8]);

        plot3(FY20(1), FY20(2), FY20(3), '^', 'MarkerSize', 12, 'MarkerFaceColor', [0.2, 0.8, 0.2], 'Color', [0, 0.6, 0], 'LineWidth', 2);
        text(FY20(1), FY20(2), FY20(3)+50, 'FY2初始位置', 'FontSize', 10, 'FontWeight', 'bold', 'Color', [0, 0.6, 0]);

        plot3(FY30(1), FY30(2), FY30(3), '^', 'MarkerSize', 12, 'MarkerFaceColor', [1, 0.5, 0], 'Color', [0.8, 0.4, 0], 'LineWidth', 2);
        text(FY30(1), FY30(2), FY30(3)+50, 'FY3初始位置', 'FontSize', 10, 'FontWeight', 'bold', 'Color', [0.8, 0.4, 0]);

        % 绘制投放点 - 使用不同颜色和更大标记
        plot3(P_d1(1), P_d1(2), P_d1(3), 'o', 'MarkerSize', 10, 'MarkerFaceColor', [0, 0.5, 1], 'Color', [0, 0, 0.8], 'LineWidth', 2);
        text(P_d1(1), P_d1(2), P_d1(3)+50, 'FY1投放点', 'FontSize', 10, 'FontWeight', 'bold', 'Color', [0, 0, 0.8]);

        plot3(P_d2(1), P_d2(2), P_d2(3), 'o', 'MarkerSize', 10, 'MarkerFaceColor', [0.2, 0.8, 0.2], 'Color', [0, 0.6, 0], 'LineWidth', 2);
        text(P_d2(1), P_d2(2), P_d2(3)+50, 'FY2投放点', 'FontSize', 10, 'FontWeight', 'bold', 'Color', [0, 0.6, 0]);

        plot3(P_d3(1), P_d3(2), P_d3(3), 'o', 'MarkerSize', 10, 'MarkerFaceColor', [1, 0.5, 0], 'Color', [0.8, 0.4, 0], 'LineWidth', 2);
        text(P_d3(1), P_d3(2), P_d3(3)+50, 'FY3投放点', 'FontSize', 10, 'FontWeight', 'bold', 'Color', [0.8, 0.4, 0]);

        % 绘制起爆点 - 使用不同颜色和更大标记
        plot3(P_b1(1), P_b1(2), P_b1(3), 's', 'MarkerSize', 10, 'MarkerFaceColor', [0.8, 0.2, 0.8], 'Color', [0.6, 0, 0.6], 'LineWidth', 2);
        text(P_b1(1), P_b1(2), P_b1(3)+50, 'FY1起爆点', 'FontSize', 10, 'FontWeight', 'bold', 'Color', [0.6, 0, 0.6]);

        plot3(P_b2(1), P_b2(2), P_b2(3), 's', 'MarkerSize', 10, 'MarkerFaceColor', [0.8, 0.2, 0.8], 'Color', [0.6, 0, 0.6], 'LineWidth', 2);
        text(P_b2(1), P_b2(2), P_b2(3)+50, 'FY2起爆点', 'FontSize', 10, 'FontWeight', 'bold', 'Color', [0.6, 0, 0.6]);

        plot3(P_b3(1), P_b3(2), P_b3(3), 's', 'MarkerSize', 10, 'MarkerFaceColor', [0.8, 0.2, 0.8], 'Color', [0.6, 0, 0.6], 'LineWidth', 2);
        text(P_b3(1), P_b3(2), P_b3(3)+50, 'FY3起爆点', 'FontSize', 10, 'FontWeight', 'bold', 'Color', [0.6, 0, 0.6]);

        % 绘制无人机轨迹 - 使用不同颜色和线宽
        drone1_t = 0:0.1:t_d1;
        drone1_pos = FY10' + (v1 * dir1)' * drone1_t;
        plot3(drone1_pos(1,:), drone1_pos(2,:), drone1_pos(3,:), '-', 'Color', [0, 0, 0.8], 'LineWidth', 2);

        drone2_t = 0:0.1:t_d2;
        drone2_pos = FY20' + (v2 * dir2)' * drone2_t;
        plot3(drone2_pos(1,:), drone2_pos(2,:), drone2_pos(3,:), '-', 'Color', [0, 0.6, 0], 'LineWidth', 2);

        drone3_t = 0:0.1:t_d3;
        drone3_pos = FY30' + (v3 * dir3)' * drone3_t;
        plot3(drone3_pos(1,:), drone3_pos(2,:), drone3_pos(3,:), '-', 'Color', [0.8, 0.4, 0], 'LineWidth', 2);

        % 添加图例
        legend('导弹路径', 'Location', 'best');

        xlabel('X (m)');
        ylabel('Y (m)');
        zlabel('Z (m)');
        title('导弹轨迹和烟幕部署', 'FontSize', 14, 'FontWeight', 'bold');

        % 调整视角以获得更好的视图
        view(-37.5, 30);
        rotate3d on;

        % 子图2：时间-遮蔽情况
        subplot(2,2,2);
        hold on;
        grid on;

        % 计算遮蔽情况
        obscured = calculateObscuration(X, g, T_target, M1_initial, V_m, FY10, FY20, FY30, t_vec, dt);

        % 绘制遮蔽情况
        area(t_vec, obscured, 'FaceColor', 'g', 'FaceAlpha', 0.3, 'EdgeColor', 'none');
        plot(t_vec, obscured, 'g-', 'LineWidth', 1.5);

        % 标记起爆时间
        line([t_b1, t_b1], [0, 1], 'Color', 'r', 'LineStyle', '--', 'LineWidth', 1);
        line([t_b2, t_b2], [0, 1], 'Color', 'r', 'LineStyle', '--', 'LineWidth', 1);
        line([t_b3, t_b3], [0, 1], 'Color', 'r', 'LineStyle', '--', 'LineWidth', 1);

        % 标记有效遮蔽时间范围
        for i = 1:3
            t_b = [t_b1, t_b2, t_b3];
            area([t_b(i), t_b(i)+20], [1, 1], 'FaceColor', 'y', 'FaceAlpha', 0.1, 'EdgeColor', 'none');
        end

        xlabel('时间 (秒)');
        ylabel('遮蔽状态');
        title('时间-遮蔽情况', 'FontSize', 14, 'FontWeight', 'bold');
        legend('遮蔽区域', '遮蔽状态', '起爆时间', '有效遮蔽期');
        ylim([0, 1.1]);

        % 子图3：烟幕云团位置随时间变化
        subplot(2,2,4);
        hold on;
        grid on;

        % 计算导弹到达目标的时间
        time_to_target = norm(M1_initial - T_target) / 300;

        % 绘制导弹位置随时间变化
        missile_x = M1_initial(1) + V_m(1) * t_vec;
        plot(t_vec, missile_x, 'r-', 'LineWidth', 2);

        % 绘制烟幕云团位置随时间变化
        for i = 1:3
            t_b = [t_b1, t_b2, t_b3];
            P_b = [P_b1; P_b2; P_b3];
            
            % 烟幕云团下沉速度
            cloud_z = zeros(size(t_vec));
            for j = 1:length(t_vec)
                if t_vec(j) >= t_b(i) && t_vec(j) <= t_b(i) + 20
                    cloud_z(j) = P_b(i,3) - 3 * (t_vec(j) - t_b(i));
                else
                    cloud_z(j) = NaN;
                end
            end
            plot(t_vec, cloud_z, '--', 'LineWidth', 1.5);
        end

        xlabel('时间 (秒)');
        ylabel('高度 (m)');
        title('导弹和烟幕云团高度随时间变化', 'FontSize', 14, 'FontWeight', 'bold');
        legend('导弹高度', '烟幕云团1', '烟幕云团2', '烟幕云团3');

        % 添加总遮蔽时间文本
        total_time = sum(obscured) * dt;
        annotation('textbox', [0.15, 0.02, 0.7, 0.05], 'String', ...
            sprintf('总遮蔽时间: %.2f 秒', total_time), ...
            'FitBoxToText', 'on', 'BackgroundColor', 'white', 'FontSize', 12, 'FontWeight', 'bold');

        hold off;
    end

    % 计算遮蔽情况的辅助函数
    function obscured = calculateObscuration(X, g, T_target, M1_initial, V_m, FY10, FY20, FY30, t_vec, dt)
        % 提取参数
        theta1 = X(1); v1 = X(2); t_d1 = X(3); dt1 = X(4);
        theta2 = X(5); v2 = X(6); t_d2 = X(7); dt2 = X(8);
        theta3 = X(9); v3 = X(10); t_d3 = X(11); dt3 = X(12);

        % 计算投放点和起爆点
        dir1 = [cos(theta1), sin(theta1), 0];
        P_d1 = FY10 + t_d1 * v1 * dir1;
        P_b1 = P_d1 + dt1 * v1 * dir1;
        P_b1(3) = P_b1(3) - 0.5 * g * dt1^2;
        t_b1 = t_d1 + dt1;

        dir2 = [cos(theta2), sin(theta2), 0];
        P_d2 = FY20 + t_d2 * v2 * dir2;
        P_b2 = P_d2 + dt2 * v2 * dir2;
        P_b2(3) = P_b2(3) - 0.5 * g * dt2^2;
        t_b2 = t_d2 + dt2;

        dir3 = [cos(theta3), sin(theta3), 0];
        P_d3 = FY30 + t_d3 * v3 * dir3;
        P_b3 = P_d3 + dt3 * v3 * dir3;
        P_b3(3) = P_b3(3) - 0.5 * g * dt3^2;
        t_b3 = t_d3 + dt3;

        % 初始化遮蔽向量
        obscured = zeros(length(t_vec), 1);

        % 预计算导弹位置
        M_t = M1_initial' + V_m' * t_vec;

        % 检查每个时间点是否遮蔽
        for i = 1:length(t_vec)
            t = t_vec(i);
            M_pos = M_t(:, i)';
            B = T_target - M_pos;
            B_sq = dot(B, B);
            if B_sq < 1e-9
                continue;
            end
            
            % 检查云团1
            if t >= t_b1 && t <= t_b1 + 20
                tau_b = t - t_b1;
                C1 = [P_b1(1), P_b1(2), P_b1(3) - 3 * tau_b];
                A = C1 - M_pos;
                s = dot(A, B) / B_sq;
                if s >= 0 && s <= 1
                    cross_prod = norm(cross(A, B));
                    d = cross_prod / sqrt(B_sq);
                    if d < 10
                        obscured(i) = 1;
                        continue;
                    end
                end
            end
            
            % 检查云团2
            if t >= t_b2 && t <= t_b2 + 20
                tau_b = t - t_b2;
                C2 = [P_b2(1), P_b2(2), P_b2(3) - 3 * tau_b];
                A = C2 - M_pos;
                s = dot(A, B) / B_sq;
                if s >= 0 && s <= 1
                    cross_prod = norm(cross(A, B));
                    d = cross_prod / sqrt(B_sq);
                    if d < 10
                        obscured(i) = 1;
                        continue;
                    end
                end
            end
            
            % 检查云团3
            if t >= t_b3 && t <= t_b3 + 20
                tau_b = t - t_b3;
                C3 = [P_b3(1), P_b3(2), P_b3(3) - 3 * tau_b];
                A = C3 - M_pos;
                s = dot(A, B) / B_sq;
                if s >= 0 && s <= 1
                    cross_prod = norm(cross(A, B));
                    d = cross_prod / sqrt(B_sq);
                    if d < 10
                        obscured(i) = 1;
                    end
                end
            end
        end
    end
end